
/*Global definitions*/
int DIM;
int trialid;
double * peaks;
double * Xopt; /*Initialized in benchmarkhelper.c*/
double Fopt;
unsigned int isInitDone;

