
TwoDoubles f101(double* x);
TwoDoubles f102(double* x);
TwoDoubles f103(double* x);
TwoDoubles f104(double* x);
TwoDoubles f105(double* x);
TwoDoubles f106(double* x);
TwoDoubles f107(double* x);
TwoDoubles f108(double* x);
TwoDoubles f109(double* x);
TwoDoubles f110(double* x);
TwoDoubles f111(double* x);
TwoDoubles f112(double* x);
TwoDoubles f113(double* x);
TwoDoubles f114(double* x);
TwoDoubles f115(double* x);
TwoDoubles f116(double* x);
TwoDoubles f117(double* x);
TwoDoubles f118(double* x);
TwoDoubles f119(double* x);
TwoDoubles f120(double* x);
TwoDoubles f121(double* x);
TwoDoubles f122(double* x);
TwoDoubles f123(double* x);
TwoDoubles f124(double* x);
TwoDoubles f125(double* x);
TwoDoubles f126(double* x);
TwoDoubles f127(double* x);
TwoDoubles f128(double* x);
TwoDoubles f129(double* x);
TwoDoubles f130(double* x);

void initbenchmarksnoisy(void);
void finibenchmarksnoisy(void);

extern bbobFunction handlesNoisy[30];
extern unsigned int handlesNoisyLength;

